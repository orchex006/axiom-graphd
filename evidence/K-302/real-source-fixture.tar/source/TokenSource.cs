namespace Demo;
public class TokenSource { public string Issue() => "ok"; }
public sealed class WatcherAdded { }
